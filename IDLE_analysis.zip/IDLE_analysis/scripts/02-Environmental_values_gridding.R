# script/02_interpolate_tracks.R
# Input: Climatic and anthropogenic stressors 
# Output: data/3-Stressors_gridded_Normalized.RDS


## Extract environnemental values for the grid size/extent 
## 2 Anthropogenic stressors: MT and Fisheries 
## 2 climatic stressors: SSTA and Chl-a anomalies 
library(raster)
library(terra)
library(lubridate)
library(tidyverse)
library(ncdf4)
library(dplyr)
library(tidyr)
library(stringr)

rm(list=ls())
gc()

############PREP CHL-A TRENDS##############################
# downloaded monthly chl-a data from 1997 to 2017 on Copernicus 
# https://data.marine.copernicus.eu/product/OCEANCOLOUR_GLO_BGC_L4_MY_009_104/download?dataset=cmems_obs-oc_glo_bgc-plankton_my_l4-multi-4km_P1M_202411

CHL_path <- file.path(".../environmental_data/CHL/cmems_obs-oc_glo_bgc-plankton_my_l4-multi-4km_P1M_1753610703455.nc") 
chl_rast <- rast(CHL_path)
names(chl_rast)

nc <- nc_open(CHL_path)
time_raw <- ncvar_get(nc, "time")
nc_close(nc)

dates <- as.POSIXct(time_raw, origin = "1970-01-01", tz = "UTC")
names(chl_rast) <- format(dates, "%Y-%m")

# Years for trend 
years <- 1997:2013
target_months <- paste0(years, "-12")
chl_dec <- chl_rast[[which(names(chl_rast) %in% target_months)]]

chl_mean <- mean(chl_dec, na.rm = TRUE)
plot(chl_mean)

chl_study <- chl_rast[[which(names(chl_rast) %in% paste0(2014:2017, "-12"))]]
chl_anomalies <- chl_study - chl_mean
plot(chl_anomalies)
writeRaster(chl_mean, ".../environmental_data/CHL/Trend_1997_2013.tiff" )

# Save Chl-Anomalies files
names(chl_anomalies)
years <- 2014:2017

output_dir <- ".../environmental_data/CHL/Anomalies/"
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)

for (i in seq_along(years)) {
  year <- years[i]
  layer <- chl_anomalies[[i]]
  filename <- file.path(output_dir, paste0("chl_anomaly_december_", year, ".tif"))
  writeRaster(layer, filename, overwrite = TRUE)
}


############PREP SST-A TRENDS##############################
# downloaded daily SST data from 1981 to 2022 on Copernicus 
# https://data.marine.copernicus.eu/product/SST_GLO_SST_L4_REP_OBSERVATIONS_010_011/description
rm(list=ls())
gc()

SST_path <- file.path(".../environmental_data/SST/METOFFICE-GLO-SST-L4-REP-OBS-SST_1753544835366.nc")
sst_rast <- rast(SST_path)

nc <- nc_open(SST_path)
time_raw <- ncvar_get(nc, "time")
nc$var$analysed_sst$units   # unit is Kelvin
nc_close(nc)

dates <- as.POSIXct(time_raw, origin = "1970-01-01", tz = "UTC")
names(sst_rast) <- format(dates, "%Y-%m-%d")

dates_df <- data.frame(
  date = dates,
  year = format(dates, "%Y"),
  month = format(dates, "%m"))

###########TREND 
dec_idx <- which(dates_df$month == "12" & dates_df$year %in% as.character(1981:2013))
dec_layers <- sst_rast[[dec_idx]]
dec_layers_c <- dec_layers - 273.15 #convert to °C

# Mean per year for the month of december, in °C
dates_dec <- dates[dec_idx]
years_dec <- format(dates_dec, "%Y")
names(dec_layers_c) <- years_dec

dec_by_year <- lapply(unique(years_dec), function(y) {
  mean(dec_layers_c[[which(years_dec == y)]], na.rm = TRUE)
})
dec_stack <- rast(dec_by_year)
names(dec_stack) <- unique(years_dec)
plot(dec_stack)

# Mean 1981-2013
sst_trend <- mean(dec_stack, na.rm = TRUE)
plot(sst_trend)
writeRaster(sst_trend, ".../environmental_data/SST/Trend_1981_2013.tiff" )


###########Yearly SSTA
#Anomalies 
study_years <- 2014:2017
dec_idy <- which(dates_df$month == "12" & dates_df$year %in% as.character(2014:2017))
dec_layers <- sst_rast[[dec_idy]]
dec_layers_c <- dec_layers - 273.15 

# # Mean per year for the month of december, in °C
dates_dec <- dates[dec_idy]
years_dec <- format(dates_dec, "%Y")

means_study <- lapply(unique(years_dec), function(y) {
  mean(dec_layers_c[[which(years_dec == y)]], na.rm = TRUE)
})

anomalies_study <- lapply(means_study, function(r) r - sst_trend)
SSTA <- rast(anomalies_study)
plot(SSTA)

# Save SST-Anomalies files
years <- 2014:2017

output_dir <- ".../environmental_data/SST/Anomalies/"
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)

for (i in seq_along(years)) {
  year <- years[i]
  layer <- SSTA[[i]]
  filename <- file.path(output_dir, paste0("sst_anomaly_december_", year, ".tif"))
  writeRaster(layer, filename, overwrite = TRUE)
}


##############GRID########################
rm(list = ls())
gc()

target_res <- 0.05
grid <- rast(ncols = 80, nrows = 40, xmin = -66.5, xmax = -62.5, ymin = -56, ymax = -54) #study area

folders <- list(
  SSTA = ".../environmental_data/SST/Anomalies/",
  Chla = ".../environmental_data/CHL/Anomalies/",
  MT = ".../environmental_data/MT/", ## Maritime Traffic, downloaded at: https://globalmaritimetraffic.org/
  Fish = ".../environmental_data/Fisheries/") ##Fisheries, downloaded at: https://globalfishingwatch.org/

load_rasters <- function(folder_path) {
  files <- list.files(folder_path, pattern = "\\.tif$", full.names = TRUE)
  rast_list <- lapply(files, terra::rast)
  names(rast_list) <- basename(files)
  return(rast_list)
}

chl_rasters  <- load_rasters(folders$Chla)
ssta_rasters <- load_rasters(folders$SSTA)
mt_rasters   <- load_rasters(folders$MT)
fish_rasters <- load_rasters(folders$Fish)

align_and_resample <- function(rast_list, template_grid) {
  aligned <- lapply(rast_list, function(r) {
    if (!terra::compareGeom(r, template_grid, stopOnError = FALSE)) {
      terra::resample(r, template_grid, method = "bilinear")
    } else {
      r
    }
  })
  return(aligned)
}

chl_aligned <- align_and_resample(chl_rasters, grid)
ssta_aligned <- align_and_resample(ssta_rasters, grid)
MT_aligned <- align_and_resample(mt_rasters, grid)
fish_aligned <- align_and_resample(fish_rasters, grid)

extract_values_year <- function(rast_list) {
  df_list <- lapply(seq_along(rast_list), function(i) {
    r <- rast_list[[i]]
    year <- stringr::str_extract(names(rast_list)[i], "\\d{4}") |> as.integer()
    r_df <- as.data.frame(r, xy = TRUE, na.rm = FALSE)
    colnames(r_df) <- c("x", "y", "raw")
    r_df$year <- year
    r_df <- r_df[, c("year", "x", "y", "raw")]
    return(r_df)
  })
  bind_rows(df_list)
}

chl_df <- extract_values_year(chl_aligned)
ssta_df <- extract_values_year(ssta_aligned)
MT_df <- extract_values_year(MT_aligned)
Fish_df <- extract_values_year(fish_aligned)

normalize_0_1 <- function(x) {
  rng <- range(x, na.rm = TRUE)
  (x - rng[1]) / (rng[2] - rng[1])
}

## Anthropogenic stressors: log[X+1] transformation then normalization (0-1)
hist(Fish_df$raw)
hist(MT_df$raw) # log transformation for both anthropogenic stressors

Fish_df$raw[is.na(Fish_df$raw)] <- 0
MT_df$raw[is.na(MT_df$raw)] <- 0

MT_df <- MT_df %>%
  mutate(log = log1p(raw))%>%
  mutate(normalized = normalize_0_1(log))

Fish_df <- Fish_df %>%
  mutate(log = log1p(raw))%>%
  mutate(normalized = normalize_0_1(log))

### Climatic stressors: normalization only, on absolute values (0-1)
chl_df <- chl_df %>%
  mutate(abs_raw = abs(raw),
  normalized = (abs_raw - min(abs_raw, na.rm = TRUE)) / 
    (max(abs_raw, na.rm = TRUE) - min(abs_raw, na.rm = TRUE))) 

ssta_df <- ssta_df %>% 
  mutate(
    abs_raw = abs(raw),
    normalized = (abs_raw - min(abs_raw, na.rm = TRUE)) /
      (max(abs_raw, na.rm = TRUE) - min(abs_raw, na.rm = TRUE)))


saveRDS(ssta_df, ".../environmental_data/SST/dataset_SSTA_normalized.rds" )
saveRDS(chl_df, ".../environmental_data/CHL/dataset_CHL_normalized.rds" )
saveRDS(MT_df, ".../environmental_data/MT/dataset_MT_normalized.rds" )
saveRDS(Fish_df, ".../environmental_data/Fisheries/dataset_Fisheries_normalized.rds" )

###Save as one big df
Fish_df$stressor <- "FISH"
MT_df$stressor   <- "MT"
ssta_df$stressor <- "SSTA"
chl_df$stressor  <- "CHLA"

common_cols <- c("year", "stressor", "x", "y", "raw", "normalized")

Fish_df <- Fish_df[, common_cols]
MT_df   <- MT_df[, common_cols]
ssta_df <- ssta_df[, common_cols]
chl_df  <- chl_df[, common_cols]

all_stressors_df <- bind_rows(SSTA = ssta_df,
                              CHLA = chl_df,
                              MT   = MT_df,
                              FISH = Fish_df)

glimpse(all_stressors_df)

saveRDS (all_stressors_df, ".../data/3-Stressors_gridded_Normalized.rds")
