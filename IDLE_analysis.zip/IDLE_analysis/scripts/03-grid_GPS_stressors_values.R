# script/03_grid_GPS_stressors_values.R
# Input: 
  # - 3-Stressors_gridded_Normalized.RDS
  # - 2- Interpolated tracks at sea
# Output: 
# - Climatic, anthropogenic and cumulative exposure scores

rm(list=ls())
gc()

library(dplyr)
library(lubridate)
library(sf)

data <- readRDS (".../data/2-Interpolated_tracks_at_sea.RDS")

##### 1- GRID GPS points #######
lat_breaks <- seq(-56, -54, by = 0.05)
long_breaks <- seq(-66.5, -62.5, by = 0.05)

data$lat_bin <- cut(data$lat, breaks = lat_breaks, include.lowest = TRUE)
data$long_bin <- cut(data$long, breaks = long_breaks, include.lowest = TRUE)
data$cell_id <- paste(data$long_bin, data$lat_bin, sep = "_")

data$year <- ifelse(
  month(data$POSIX) %in% c(1, 2),        #Jan-Feb -> N-1
  year(data$POSIX) - 1,
  year(data$POSIX))                      #Oct-Nov-Dec -> N

grid_counts <- data %>%
  group_by(species, year, cell_id, long_bin, lat_bin) %>%
  summarise(n_points = n(), .groups = "drop")

grid_freq <- grid_counts %>%
  group_by(species, year) %>%
  mutate(freq_rel = n_points / sum(n_points)) %>%
  ungroup()

grid_freq <- grid_freq %>%
  mutate(
    long_center = as.numeric(sub("\\((.+),.*", "\\1", long_bin)) + 0.025,
    lat_center = as.numeric(sub(".*,\\s*(.+)\\]", "\\1", lat_bin)) - 0.025)

grid_sf <- st_as_sf(grid_freq, coords = c("long_center", "lat_center"), crs = 4326)

##Quick plot to check data distribution
ggplot(grid_freq, aes(x = long_center, y = lat_center, fill = freq_rel)) +
  geom_tile(width = 0.05, height = 0.05) +
  coord_fixed() +
  scale_fill_viridis_c(option = "magma") +
  facet_wrap(~ species + year) +
  theme_minimal() 

###################2- Prep for calculation of 3 exposure scores: ########################
#climatic, anthropogenic and cumulative
#Exp. score = relative frequency * (Stressor1 + Stressor2 + etc)
stressors <- readRDS(".../data/3-Stressors_gridded_Normalized.rds")
dataID <- as.data.frame(grid_freq)

######## 3- Calculation Anthropique score ################
data_stress_A <- dataID %>%
  mutate(across(c(long_center, lat_center), ~ round(.x, 4))) %>%
  left_join(stressors %>%
              mutate(across(c(x, y), ~ round(.x, 4))),
            by = c("year" = "year",
                   "long_center" = "x",
                   "lat_center" = "y")) %>%
  dplyr::select(-raw) %>%
  filter(stressor %in% c("FISH", "MT")) 

data_stress_A_sum <- data_stress_A %>%
  group_by(long_center, lat_center, year, species, cell_id, 
            long_bin, lat_bin,n_points, freq_rel) %>%
  summarise(sum_normalized = sum(normalized, na.rm = TRUE)) %>%
  mutate(A_score = freq_rel * sum_normalized) 

saveRDS(data_stress_A_sum, ".../data/4-Anthropogenic_exposure_score.rds")


######## 4- Calculation Climatic score ################
data_stress_C <- dataID %>%
  mutate(across(c(long_center, lat_center), ~ round(.x, 4))) %>%
  left_join(stressors %>%
              mutate(across(c(x, y), ~ round(.x, 4))),
            by = c("year" = "year",
                   "long_center" = "x",
                   "lat_center" = "y")) %>%
  dplyr::select(-raw) %>%
  filter(stressor %in% c("CHLA", "SSTA")) 

data_stress_C_sum <- data_stress_C %>%
  group_by(long_center, lat_center, year, species, cell_id, 
           long_bin, lat_bin,n_points, freq_rel) %>%
  summarise(sum_normalized = sum(normalized, na.rm=F)) %>%
  mutate(C_score = freq_rel * sum_normalized) 

saveRDS(data_stress_C_sum, ".../data/4-Climatic_exposure_score.rds")

############# 5- Calculation Cumulative Score#########################
data_Cumul <- dataID %>%
  mutate(across(c(long_center, lat_center), ~ round(.x, 4))) %>%
  left_join(stressors %>%
              mutate(across(c(x, y), ~ round(.x, 4))),
            by = c("year" = "year",
                   "long_center" = "x",
                   "lat_center" = "y")) %>%
  dplyr::select(-raw) 

data_cumul_sum <- data_Cumul %>% ## here is yearly cumulative score 
  group_by(long_center, lat_center, year, species, cell_id, 
           long_bin, lat_bin,n_points, freq_rel) %>%
  summarise(sum_normalized = sum(normalized, na.rm=F)) %>%
  mutate(C_score = freq_rel * sum_normalized) 

Cumulatif <- data_cumul_sum %>% ## averaged cumulative score for the entire study period
  group_by(species, cell_id, long_center, lat_center) %>%
  summarise(
    freq_avg = mean(freq_rel, na.rm = TRUE),
    stress_avg = mean(sum_normalized, na.rm = TRUE), .groups = "drop") %>%
  mutate(cumulative_index = freq_avg * stress_avg)

Cumulatif <- Cumulatif[complete.cases(Cumulatif[, c("cumulative_index", "long_center", "lat_center", "species", "cell_id")]), ]


saveRDS(Cumulatif, ".../data/5-Cumulative_exposure_score.rds")

