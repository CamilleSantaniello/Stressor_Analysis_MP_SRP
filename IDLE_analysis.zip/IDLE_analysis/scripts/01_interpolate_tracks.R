# script/01_interpolate_tracks.R
# Input: data/1-Dataset.rds 
# Output: data/2-Interpolated_tracks_at_sea.RDS 

library(sf) 
library(tidyverse)
library(lubridate)
library(ggplot2)
library(sp)
library(ggspatial)
library(momentuHMM)
library(conicfit)
library(gridExtra)
library(geosphere)
library(dplyr)

rm(list = ls())

in_rds  <- ".../data/1-Dataset.rds"
out_rds <- ".../data/2-Interpolated_tracks_at_sea.rds"
coast_dir <- file.path(".../environmental_data/coastline") 
## shapefile of the coastline was downloaded at https://www.ign.gob.ar/NuestrasActividades/InformacionGeoespacial/CapasSIG (layer 'area de desarollo de fronteras')

data <- readRDS(in_rds)

#### 1- Filter points at-sea using high resolution shp for coastline ####
coastlineTDF<- read_sf(coast_dir)
bbox_crop <- st_bbox(c( xmin = -68, xmax = -62,  ymin = -57, ymax = -53), crs = st_crs(coastlineTDF))
coastlineTDF <- st_crop(coastlineTDF, bbox_crop)

data_sf <- st_as_sf(data, coords = c("long", "lat"), crs = 4326, remove = FALSE)
coastlineTDF <- st_transform(coastlineTDF, crs = st_crs(data_sf))

on_land <- st_intersects(data_sf,coastlineTDF, sparse = FALSE)
table(on_land)

data_sea_only <- data_sf[!on_land, ]
data_sea_df <- as.data.frame(data_sea_only)

#### 2- Prep data for interpolation + filter tracks with <20 points at-sea ####
data_filtered <- data_sea_df
coordinates(data_filtered) <- ~long + lat  
proj4string(data_filtered) <- CRS("+proj=longlat +datum=WGS84") 
new_crs <- "+proj=utm +zone=21 +south +datum=WGS84 +units=m +no_defs"
data_proj <- spTransform(data_filtered, CRS(new_crs))

obstimes <- as.numeric(data_proj$POSIX) / 3600  
lnError <- crawl::argosDiag2Cov(50, 50, 0)  

lpdata <- data.frame(
  ID = data_proj$ID,  
  time = obstimes,
  x = data_proj@coords[, 1],  
  y = data_proj@coords[, 2],  
  ln.sd.x = lnError$ln.sd.x, 
  ln.sd.y = lnError$ln.sd.y,
  error.corr = lnError$error.corr)

lpdata <- lpdata[!duplicated(lpdata[, c("ID", "time", "x", "y")]), ]

lpdata <- lpdata %>%
  group_by(ID) %>%
  filter(n() >= 20) %>% ##keep only when >20 observations
  ungroup()

lpdata <- lpdata %>%
  arrange(ID, time)

str(lpdata)

#### 3- Interpolation of the tracks with package crawl #####
crwOut <- crawlWrap(lpdata, theta = c(6.5, -0.1), fixPar = c(1, 1, NA, NA),
                    err.model = list(x = ~ln.sd.x - 1, y = ~ln.sd.y - 1, rho = ~error.corr),
                    timeStep =  60 / 3600,  # Predict at 1min intervals
                    attempts = 10)


#### 4- Check interpolated tracks ####
crw_data <- as.data.frame(crwOut$crwPredict)
unique_ids <- unique(crw_data$ID)  

for (id in unique_ids) {
  individual_data <- crw_data[crw_data$ID == id &
                                !is.na(crw_data$mu.x) &
                                !is.na(crw_data$mu.y), ]
  
  if (nrow(individual_data) == 0) {
    message(paste("No data for ", id))
    next
  }
  
  observed <- individual_data[individual_data$locType == "o", ]
  predicted <- individual_data[individual_data$locType == "p", ]
  
  p1 <- ggplot(observed, aes(x = mu.x, y = mu.y)) +
    geom_path(color = "blue") +
    geom_point(size = 0.5, color = "blue") +
    ggtitle(paste("Observed ", id)) +
    theme_minimal() +
    coord_fixed()
  
  p2 <- ggplot(predicted, aes(x = mu.x, y = mu.y)) +
    geom_path(color = "red") +
    geom_point(size = 0.5, color = "red") +
    ggtitle(paste("Predicted ", id)) +
    theme_minimal() +
    coord_fixed()
  
  grid.arrange(p1, p2, ncol = 2)
  readline(prompt = "press enter for next plot")
}

#############5- Prepare dataset for next steps ##################
crw_data_df <- crw_data
class(crw_data_df) <- "data.frame"  

## get original datetime back
crw_data_df$Datetime <- as.POSIXct(crw_data_df$time * 3600, origin = "1970-01-01", tz = "UTC")

## get coordinates in degrees 
coords_mu <- data.frame(x = crw_data_df$mu.x, y = crw_data_df$mu.y)
sp_mu <- SpatialPoints(coords_mu, proj4string = CRS("+proj=utm +zone=21 +south +datum=WGS84 +units=m +no_defs"))
sp_mu_longlat <- spTransform(sp_mu, CRS("+proj=longlat +datum=WGS84"))
crw_data_df$long <- coordinates(sp_mu_longlat)[, 1]
crw_data_df$lat <- coordinates(sp_mu_longlat)[, 2]

## get back info on species/ID/sex
info_cols <- data %>% 
  distinct(ID, species, Sex)  
crw_data_final <- left_join(crw_data_df, info_cols, by = "ID")

## clean variables
crw_data_final <- crw_data_final %>%
  dplyr::select(ID, species, Sex, long, lat, mu.x, mu.y, speed, TimeNum, Datetime, POSIX = Datetime, locType, x, y)
df_final <- crw_data_final[, c("ID", "species", "Sex", "long", "lat", "mu.x", "mu.y", "POSIX", "locType")]

## keep only predicted occurrences for regular timestep
df_final <- df_final %>%
  filter(locType =="p") %>%
  dplyr::select(-(locType))


##########6- Save output dataset###############
saveRDS(df_final, "out_rds")