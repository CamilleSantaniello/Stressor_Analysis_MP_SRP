# script/04_stats_exposure_scores.R
# Input: Climatic, anthropogenic and cumulative exposure scores
# Output: Models and predictions plots for each exposure score

library(FactoMineR)
library(dplyr)
library(factoextra)
library(tidyr)
library(gridExtra)
library(glue)
library(DHARMa)
library(glmmTMB)
library(ggplot2)
library(data.table)
library(mgcv)
library(spdep)
library(ncf)
library(purrr)
library(tseries)
library(emmeans)
library(multcomp)
library(patchwork)


rm(list=ls())

####################Climatic exposure score ###############################
Climatic <- readRDS (".../data/4-Climatic_exposure_score.rds")
Climatic <- Climatic[complete.cases(Climatic[, c("C_score", "long_center", "lat_center", "species", "year", "cell_id")]), ]

Climatic$year <- as.factor(Climatic$year)
Climatic$species <- as.factor(Climatic$species)
Climatic$cell_id <- as.factor(Climatic$cell_id)

hist(Climatic$C_score) 
fitdistrplus::descdist(Climatic$C_score) ##gamma distribution is appropiate

## Interactions
Climatic$sp_year <- interaction(Climatic$species, Climatic$year)
Climatic$cell_year <- interaction(Climatic$cell_id, Climatic$year)

#Final model
gam_clim_final <- bam(
  C_score ~ 
    te(long_center, lat_center, by = sp_year, k = c(8, 8)) +
    species * year +   
    s(cell_year, bs = "re"),  # repeated measures
  family = Gamma(link = "log"),
  method = "fREML",
  data = Climatic)

# Diagnostic
gam.check(gam_clim_final)
plot(gam_clim_final, pages = 1, residuals = TRUE)
summary(gam_clim_final)

# Pearson residuals
res_pearson <- residuals(gam_clim_final, type = "pearson")
plot(fitted(gam_clim_final), res_pearson,
     xlab = "Fitted values", ylab = "Pearson residuals",
     main = "Pearson residuals vs Fitted")
abline(h = 0, col = "red")

# Moran I test for spatial autocorrelation
coords <- Climatic %>% 
ungroup() %>%
  dplyr::select(long_center, lat_center)
coords <- as.matrix(coords)
nb <- dnearneigh(coords, 0, 0.5)  
listw <- nb2listw(nb, style = "W")
Climatic$res <- residuals(gam_clim_final)

moran <- moran.test(Climatic$res, listw)
print(moran)

## Ljung-Box for temporal autocorrelation 
ljung_results <- Climatic %>%
  group_by(cell_id) %>%
 # filter(n() > 3) %>% #should be done in larger dataset
  group_modify(~ {
    x <- .x$C_score
    test <- tryCatch(Box.test(x, lag = 1, type = "Ljung-Box"), error = function(e) NULL)
    if (!is.null(test)) {
      tibble(statistic = test$statistic, p_value = test$p.value)
    } else {
      tibble(statistic = NA, p_value = NA)
    }
  }) %>%
  ungroup()

mean(ljung_results$p_value < 0.05, na.rm = TRUE)

saveRDS(gam_clim_final, ".../6-Climatic_exposure_model.rds")

#############Antropogenic exposure score #############################
Ant <- readRDS (".../4-Anthropogenic_exposure_score.rds")
Ant <- Ant[complete.cases(Ant[, c("A_score", "long_center", "lat_center", "species", "year", "cell_id")]), ]

Ant$year <- as.factor(Ant$year)
Ant$species <- as.factor(Ant$species)
Ant$cell_id <- as.factor(Ant$cell_id)

hist(Ant$A_score) 
fitdistrplus::descdist(Ant$A_score) ### tweedie distribution   

## Interactions
Ant$sp_year <- interaction(Ant$species, Ant$year)
Ant$cell_year <- interaction(Ant$cell_id, Ant$year)

#Final model (highest R², highest dev. explained, lowest AIC)
gam_model_ant <- bam( 
  A_score ~ 
    te(long_center, lat_center, by = sp_year, k = c(8, 8)) +
    species * year + 
    s(cell_year, bs = "re"), 
  family = tw(link = "log"),
  method = "fREML",
  data = Ant,
  discrete=F)
# here the subset is too small and doesnt have enough variation in A_score 
# for the model to capture its variations as well as in the full dataset 

summary(gam_model_ant) 
gam.check(gam_model_ant)
plot(gam_model_ant, pages = 1, residuals = TRUE)

# Pearson residuals
res_pearson <- residuals(gam_model_ant, type = "pearson")
plot(fitted(gam_model_ant), res_pearson,
     xlab = "Fitted values", ylab = "Pearson residuals",
     main = "Pearson residuals vs Fitted")
abline(h = 0, col = "red") # not enough cells with exposure in the subset

# Moran I test for spatial autocorrelation
coords <- Ant %>% 
  ungroup() %>%
  dplyr::select(long_center, lat_center)
coords <- as.matrix(coords)
nb <- dnearneigh(coords, 0, 0.5)  
listw <- nb2listw(nb, style = "W")
Ant$res <- residuals(gam_model_ant)

moran <- moran.test(Ant$res, listw)
print(moran)

## Ljung-Box for temporal autocorrelation 
ljung_results <- Ant %>%
  group_by(cell_id) %>%
  # filter(n() > 3) %>% #should be done in larger dataset
  group_modify(~ {
    x <- .x$A_score
    test <- tryCatch(Box.test(x, lag = 1, type = "Ljung-Box"), error = function(e) NULL)
    if (!is.null(test)) {
      tibble(statistic = test$statistic, p_value = test$p.value)
    } else {
      tibble(statistic = NA, p_value = NA)
    }
  }) %>%
  ungroup()

mean(ljung_results$p_value < 0.05, na.rm = TRUE)

saveRDS(gam_model_ant, ".../data/7-Anthropogenic_exposure_model.rds")

########### Visualize predicted yearly variation in exposure to climatic and anthropogenic stressors###################
anthropic_model <- gam_model_ant
climatic_model <- gam_clim_final

# 1) calcul of EMMs on response scale for ech model
emm_link_C <- emmeans(climatic_model,  ~ species * year)
emm_link_A <- emmeans(anthropic_model, ~ species * year)

df_C <- as.data.frame(summary(emm_link_C, type = "response")) %>% mutate(stressor = "Climatic")
df_A <- as.data.frame(summary(emm_link_A, type = "response")) %>% mutate(stressor = "Anthropogenic")
df_C <- df_C[complete.cases(df_C[, c("response", "SE")]), ]
df_A <- df_A[complete.cases(df_A[, c("response", "SE")]), ]

# 2) CLD per species
emm_by_sp_C <- emmeans(climatic_model,  ~ year | species)
emm_by_sp_A <- emmeans(anthropic_model, ~ year | species)

cld_C <- as.data.frame(cld(emm_by_sp_C, adjust = "tukey", type = "response", Letters= letters)) %>%
  mutate(stressor = "Climatic") %>%
  dplyr::select(species, year, .group, stressor)%>% 
  filter (!(.group == ""))

cld_A <- as.data.frame(cld(emm_by_sp_A, adjust = "tukey", type = "response", Letters=letters)) %>%
  mutate(stressor = "Anthropogenic") %>%
  dplyr::select(species, year, .group, stressor) %>%
  filter (!(.group == ""))


# 3) Plot yearly predicted exposure
all_df <- bind_rows(df_C, df_A) %>%
  left_join(bind_rows(cld_C, cld_A), by = c("species","year","stressor")) %>%
  mutate(
    year     = factor(year, levels = sort(unique(as.numeric(as.character(year))))),
    year_num = as.numeric(as.character(year)),
    species  = factor(species, levels = c("MP","SRP")),
    stressor = factor(stressor, levels = c("Climatic","Anthropogenic")) )

grp_levels <- all_df %>%
  pull(.group) %>% unique() %>% na.omit() %>%
  (\(x) x[order(nchar(x), x)])()
pal <- viridis::viridis(length(grp_levels), option = "inferno")
names(pal) <- grp_levels

p_year_means_cld <- ggplot(all_df, aes(year_num, response, group = 1)) +
  geom_line(linewidth = 0.6, colour = "grey40", na.rm = TRUE) +
  geom_errorbar(aes(ymin = lower.CL, ymax = upper.CL, colour = .group),
                width = 0.18, linewidth = 0.7, na.rm = TRUE, show.legend = TRUE) +
  geom_point(aes(colour = .group), size = 2.4, na.rm = TRUE, show.legend = TRUE) +
  geom_text(
    aes(y = upper.CL, label = .group),
    vjust = -0.6, size = 3.2, show.legend = FALSE)+
  facet_grid(rows = vars(stressor), cols = vars(species), scales = "free_y") +
  scale_x_continuous(breaks = sort(unique(all_df$year_num))) +
  coord_cartesian(clip = "off") +
  scale_colour_manual(
    values = pal,
    limits = grp_levels,                      
    name   = "Tukey groups\n(within species)",
    guide  = guide_legend(
      override.aes = list(shape = 16, size = 3), 
      ncol = 2, byrow = TRUE, keywidth = 0.9, keyheight = 0.9)) +
  labs(x = "Year", y = "Predicted exposure (mean ± 95% CI)") +
  theme_classic(base_size = 11) +
  theme(
    plot.margin        = margin(6, 6, 6, 6),
    axis.ticks.length  = unit(2, "pt"),
    legend.position    = "right",           
    legend.box.margin  = margin(0, 0, 2, 0),
    panel.border       = element_rect(colour = "black", fill = NA, linewidth = 0.3),
    panel.spacing.x    = unit(12, "pt"),
    panel.spacing.y    = unit(12, "pt")
  )

p_year_means_cld ## CIs are wide because of few exposed points in this subset increasing the model uncertainty

###############Model for Cumulative exposure score #################
Cumulatif <- readRDS(".../data/5-Cumulative_exposure_score.rds")
Cumulatif$species <- as.factor(Cumulatif$species)
Cumulatif$cell_id <- as.factor(Cumulatif$cell_id)

hist(Cumulatif$cumulative_index) 
fitdistrplus::descdist(Cumulatif$cumulative_index) ## gamma distribution

## Better model for Cumulative exposure 
gam_model_cumulative <- bam(
  cumulative_index ~ 
    s(long_center, by = species, k = 5) +
    s(lat_center, by = species, k = 5) +
    ti(long_center, lat_center, by = species, k = 10) +
    species +
    s(cell_id, bs = "re"),  #random effect of cell_id
  family = Gamma(link = "log"),
  method = "fREML",
  data = Cumulatif, 
  discrete = F)

#Diagnostics
gam.check(gam_model_cumulative)
summary(gam_model_cumulative)
plot(gam_model_cumulative, pages = 1, residuals = TRUE)

# Pearson residuals
res_pearson <- residuals(gam_model_cumulative, type = "pearson")
plot(fitted(gam_model_cumulative), res_pearson,
     xlab = "Fitted values", ylab = "Pearson residuals",
     main = "Pearson residuals vs Fitted")
abline(h = 0, col = "red")

# Spatial autocorrelation
coords <- Cumulatif %>% 
  ungroup() %>%
  dplyr::select(long_center, lat_center)
coords <- as.matrix(coords)
nb <- dnearneigh(coords, 0, 0.5)  
listw <- nb2listw(nb, style = "W")
Cumulatif$res <- residuals(gam_model_cumulative)

moran <- moran.test(Cumulatif$res, listw)
print(moran)

saveRDS(gam_model_cumulative, ".../data/8-Cumulative_exposure_model.rds")

########## Predicted variation in cumulative exposure with long/lat###################
# Predictions with 1 fixed predictor (using median value) and 1 varying 
levels_species <- levels(Cumulatif$species)
levels_cell    <- levels(Cumulatif$cell_id)

## fixed longitude
med_by_sp <- Cumulatif %>%
  group_by(species) %>%
  summarise(
    long_med = median(long_center, na.rm = TRUE),
    lat_min  = min(lat_center, na.rm = TRUE),
    lat_max  = max(lat_center, na.rm = TRUE))

#MP
nd_lat_MP <- {
  lat_seq_MP <- seq(
    med_by_sp$lat_min[med_by_sp$species == levels_species[1]],
    med_by_sp$lat_max[med_by_sp$species == levels_species[1]],
    length.out = 200)
  long_fix_MP <- med_by_sp$long_med[med_by_sp$species == levels_species[1]]
  
  data.frame(
    species     = factor(levels_species[1], levels = levels_species),
    lat_center  = lat_seq_MP,
    long_center = long_fix_MP,
    cell_id     = factor(NA, levels = levels_cell))
}

# SRP 
nd_lat_SRP <- {
  lat_seq_SRP <- seq(
    med_by_sp$lat_min[med_by_sp$species == levels_species[2]],
    med_by_sp$lat_max[med_by_sp$species == levels_species[2]],
    length.out = 200)
  long_fix_SRP <- med_by_sp$long_med[med_by_sp$species == levels_species[2]]
  
  data.frame(
    species     = factor(levels_species[2], levels = levels_species),
    lat_center  = lat_seq_SRP,
    long_center = long_fix_SRP,
    cell_id     = factor(NA, levels = levels_cell))
}

nd_lat <- rbind(nd_lat_MP, nd_lat_SRP)

lvl1 <- levels(Cumulatif$cell_id)[1]
nd_lat$cell_id <- factor(lvl1, levels = levels(Cumulatif$cell_id))

### predict variation with varying lat
pred_lat <- predict(
  gam_model_cumulative, newdata = nd_lat,
  type = "link", se.fit = TRUE,
  exclude = "s(cell_id)")

nd_lat <- nd_lat %>%
  mutate(
    fit_link = pred_lat$fit,
    se_link =pred_lat$se.fit, 
    predicted = exp(fit_link),
    conf.low  = exp(fit_link - 1.96 * se_link),
    conf.high = exp(fit_link + 1.96 * se_link))


#### Fixed lat, varying longitude 
med_by_sp2 <- Cumulatif %>%
  group_by(species) %>%
  summarise(
    lat_med  = median(lat_center, na.rm = TRUE),
    long_min = min(long_center, na.rm = TRUE),
    long_max = max(long_center, na.rm = TRUE))

# MP 
nd_lon_MP <- {
  lon_seq_MP <- seq(
    med_by_sp2$long_min[med_by_sp2$species == levels_species[1]],
    med_by_sp2$long_max[med_by_sp2$species == levels_species[1]],
    length.out = 200)
  lat_fix_MP <- med_by_sp2$lat_med[med_by_sp2$species == levels_species[1]]
  
  data.frame(
    species     = factor(levels_species[1], levels = levels_species),
    long_center = lon_seq_MP,
    lat_center  = lat_fix_MP,
    cell_id     = factor(NA, levels = levels_cell))
}

# SRP 
nd_lon_SRP <- {
  lon_seq_SRP <- seq(
    med_by_sp2$long_min[med_by_sp2$species == levels_species[2]],
    med_by_sp2$long_max[med_by_sp2$species == levels_species[2]],
    length.out = 200)
  lat_fix_SRP <- med_by_sp2$lat_med[med_by_sp2$species == levels_species[2]]
  
  data.frame(
    species     = factor(levels_species[2], levels = levels_species),
    long_center = lon_seq_SRP,
    lat_center  = lat_fix_SRP,
    cell_id     = factor(NA, levels = levels_cell))
}

nd_lon <- rbind(nd_lon_MP, nd_lon_SRP)

nd_lon$cell_id <- factor(lvl1, levels = levels(Cumulatif$cell_id))
pred_lon <- predict(
  gam_model_cumulative, newdata = nd_lon,
  type = "link", se.fit = TRUE,
  exclude = "s(cell_id)")

nd_lon <- nd_lon %>%
  mutate(
    fit_link = pred_lon$fit,
    se_link =  pred_lon$se.fit, 
    predicted = exp(fit_link),
    conf.low  = exp(fit_link - 1.96 * se_link),
    conf.high = exp(fit_link + 1.96 * se_link))


# Plot the predicted  variations
cols_species <- c("MP" = "springgreen1", "SRP" = "palevioletred")
ms_theme <-
  theme_classic(base_size = 11) +
  theme(
    plot.margin        = margin(6, 6, 6, 6),
    axis.title         = element_text(size = 11),
    axis.text          = element_text(size = 10),
    axis.ticks.length  = unit(2, "pt"),
    strip.background   = element_rect(fill = "grey95", colour = "grey80"),
    strip.text         = element_text(size = 11, face = "bold"),
    legend.position    = "right",
    legend.text        = element_text(size = 10),
    legend.title       = element_text(size = 11),
    panel.border       = element_rect(colour = "black", fill = NA, linewidth = 0.3),
    panel.spacing.x    = unit(12, "pt"),
    panel.spacing.y    = unit(12, "pt"),
    axis.text.x        = element_text(margin = margin(t = 3)),
    axis.text.y        = element_text(margin = margin(r = 3)))

### latitude variation
plot_lat_lin <-
  ggplot(nd_lat, aes(x = lat_center, y = predicted, colour = species, fill = species)) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.20, colour = NA) +
  geom_line(linewidth = 0.8) +
  scale_color_manual(values = cols_species, name = "Species") +
  scale_fill_manual(values  = cols_species, name = "Species") +
  labs(x = "Latitude",
       y = "Predicted cumulative exposure (mean ± 95% CI)") +
  ms_theme

## transform back on response scale 
plot_lat_log <- plot_lat_lin +
  scale_y_continuous(trans = "log10",
                     breaks = scales::trans_breaks("log10", function(x) 10^x),
                     labels = scales::label_number(accuracy = 0.0001))

## longitude variation
plot_lon_lin <-
  ggplot(nd_lon, aes(x = long_center, y = predicted, colour = species, fill = species)) +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.20, colour = NA) +
  geom_line(linewidth = 0.8) +
  scale_color_manual(values = cols_species, name = "Species") +
  scale_fill_manual(values  = cols_species, name = "Species") +
  labs(x = "Longitude",
       y = "Predicted cumulative exposure (mean ± 95% CI)") +
  ms_theme

## transform back on response scale
plot_lon_log <- plot_lon_lin +
  scale_y_continuous(trans = "log10",
                     breaks = scales::trans_breaks("log10", function(x) 10^x),
                     labels = scales::label_number(accuracy = 0.0001))

#fig_linear <- grid.arrange(plot_lat_lin, plot_lon_lin, ncol = 2)
fig_log  <- grid.arrange(plot_lat_log, plot_lon_log, ncol = 2)


###on common scale:
common_ylim <- c(0.0009, 0.02)

plot_lat_log <- plot_lat_log +
  scale_y_continuous(trans = "log10",
                     limits = common_ylim,
                     breaks = scales::trans_breaks("log10", function(x) 10^x)) +
  labs(x = "Latitude", y = "Predicted cumulative exposure (mean ± 95% CI)")

plot_lon_log <- plot_lon_lin +
  scale_y_continuous(trans = "log10",
                     limits = common_ylim,
                     breaks = scales::trans_breaks("log10", function(x) 10^x)) +
  labs(x = "Longitude", y = NULL) +
  theme(
    axis.ticks.y = element_blank(),
    axis.text.y  = element_blank(),
    axis.title.y = element_blank(), 
    axis.line.y = element_blank()
  )

combined <- plot_lat_log + plot_lon_log +
  plot_layout(guides = "collect") & theme(legend.position = "right")

combined

ggsave(".../Results_Fig_long_lat_Cumulative.png", 
       combined, width = 240, height = 100, units = "mm", dpi = 800)
